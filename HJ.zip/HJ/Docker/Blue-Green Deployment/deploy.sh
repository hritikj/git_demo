ACTIVE=$(grep "server" nginx/nginx.conf | awk '{print $2}' | cut -d: -f1 | tr -d '{}\r' | xargs)

if [ "$ACTIVE" = "blue" ]; then
    NEW="green"
    OLD="blue"
else
    NEW="blue"
    OLD="green"
fi

docker-compose build $NEW
docker-compose up -d $NEW

sed -i "s/$OLD:3000/$NEW:3000/" nginx/nginx.conf

docker exec nginx nginx -s reload

echo "Switched to $NEW"