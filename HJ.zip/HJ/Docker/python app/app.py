from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

board = [""] * 9
current_player = "X"

def check_winner():
    win_patterns = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ]
    for pattern in win_patterns:
        a, b, c = pattern
        if board[a] == board[b] == board[c] != "":
            return board[a]
    return None

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/move", methods=["POST"])
def move():
    global current_player

    data = request.json
    index = data["index"]

    if board[index] == "":
        board[index] = current_player

        winner = check_winner()
        if winner:
            result = {"status": "win", "player": winner}
            reset_board()
            return jsonify(result)

        if "" not in board:
            reset_board()
            return jsonify({"status": "draw"})

        current_player = "O" if current_player == "X" else "X"

    return jsonify({"status": "continue", "board": board, "player": current_player})

def reset_board():
    global board, current_player
    board = [""] * 9
    current_player = "X"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000,debug=True)