CREATE DATABASE IF NOT EXISTS devops;
USE devops;
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message TEXT
);

