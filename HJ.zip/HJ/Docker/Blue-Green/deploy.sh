#!/bin/bash

ACTIVE=$(grep "server" nginx/nginx.conf | awk '{print $2}' | cut -d: -f1 | tr -d '{}\r' | xargs)
echo ">$ACTIVE<"
if [ "$ACTIVE" = "blue" ]; then
    NEW="green"
    OLD="blue"
else
    NEW="blue"
    OLD="green"
fi

echo "Current: $ACTIVE → Switching to: $NEW"

# Rebuild new version
docker-compose build $NEW

# Restart new container
docker-compose up -d $NEW

# Update nginx config
sed -i "s/$OLD:3000/$NEW:3000/" nginx/nginx.conf

# Reload nginx
docker exec nginx nginx -s reload

echo "Switched to $NEW 🎉"