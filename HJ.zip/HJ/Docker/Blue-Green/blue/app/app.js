const express = require('express');
const app = express();

const VERSION = process.env.VERSION || "blue";

app.get('/', (req, res) => {
    res.send(`🚀 Running ${VERSION} version`);
});

app.listen(3000, () => console.log("Running on port 3000"));