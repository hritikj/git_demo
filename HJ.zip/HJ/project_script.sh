#!/bin/bash

#updating the system
sudo apt update

sudo apt upgrade -y

#install Apache2 server

sudo apt install apache2 -y

#install php and mysql extension

sudo apt install php libapache2-mod-php php-mysql -y
php -v

#install git, by default install in Ubuntu 24.04

sudo apt install git -y

#Cloning the code from git
git clone https://github.com/hritikj/shree.git
cd shree

#Remove the default index file

sudo rm -rf /var/www/html/*

#Copy the project files to /var/www/html/

sudo cp -rf * /var/www/html/





