#!/bin/bash

#updating the system
sudo apt update
sudo apt upgrade -y

#install php, mysql and all dependent packages
sudo apt install php mysql-server libapache2-mod-php php-mysql -y

#install Apache2 server -- by default it is enabled
sudo apt install apache2 -y
sudo systemctl start apache2

#install git, by default install in Ubuntu 24.04
sudo apt install git -y

#Cloning the code from git
git clone https://github.com/hritikj/shree.git
cd shree

#Remove the default index file
sudo rm -rf /var/www/html/*

#Copy the project files to /var/www/html/
sudo cp -rf * /var/www/html/

#Change Ownership and permission to www-data
sudo chown -R www-data:www-data /var/www/html/*
sudo chmod -R 755 /var/www/html/*

#install dos2unix for convirting EOF from Windows based to Linux based
sudo apt install dos2unix

#Run the Sql Script to create DB, user and provide all the privileges
cd /var/www/html/
dos2unix sql_script.sh
bash sql_script.sh

#Restart apache2 server
sudo systemctl restart apache2





