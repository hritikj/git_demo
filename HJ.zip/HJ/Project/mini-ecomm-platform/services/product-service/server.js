const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());

/* API Endpoint */
app.get("/api/products", (req, res) => {
  res.json([
    {
      id: 1,
      name: "Wireless Headphones",
      price: 99
    },
    {
      id: 2,
      name: "Smart Watch",
      price: 149
    },
    {
      id: 3,
      name: "Gaming Keyboard",
      price: 79
    }
  ]);
});

/* UI Page */
app.get("/products", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Products</title>

      <style>
        body {
          font-family: Arial;
          background: #f3f4f6;
          padding: 40px;
        }

        h1 {
          text-align: center;
          margin-bottom: 40px;
        }

        .products {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 20px;
        }

        .card {
          background: white;
          padding: 20px;
          border-radius: 10px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          text-align: center;
        }

        .card img {
          width: 100%;
          border-radius: 8px;
        }

        .price {
          color: #2563eb;
          font-size: 22px;
          margin: 15px 0;
        }

        button {
          background: #2563eb;
          color: white;
          border: none;
          padding: 10px 18px;
          border-radius: 6px;
          cursor: pointer;
        }
      </style>
    </head>

    <body>

      <h1>Products Page</h1>

      <div class="products">

        <div class="card">
          <img src="https://picsum.photos/300/200?1">

          <h2>Wireless Headphones</h2>

          <p class="price">$99</p>

          <button>Add To Cart</button>
        </div>

        <div class="card">
          <img src="https://picsum.photos/300/200?2">

          <h2>Smart Watch</h2>

          <p class="price">$149</p>

          <button>Add To Cart</button>
        </div>

        <div class="card">
          <img src="https://picsum.photos/300/200?3">

          <h2>Gaming Keyboard</h2>

          <p class="price">$79</p>

          <button>Add To Cart</button>
        </div>

      </div>

    </body>
    </html>
  `);
});

app.listen(3000, () => {
  console.log("Product Service Running on Port 3000");
});