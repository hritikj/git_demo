const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());

/* API */
app.get("/api/orders", (req, res) => {
  res.json([
    {
      orderId: 1001,
      status: "Delivered",
      total: 248
    },
    {
      orderId: 1002,
      status: "Processing",
      total: 99
    }
  ]);
});

/* UI */
app.get("/orders", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Orders</title>

      <style>
        body {
          font-family: Arial;
          background: #f3f4f6;
          padding: 40px;
        }

        h1 {
          text-align: center;
          margin-bottom: 30px;
        }

        .orders {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
        }

        .card {
          background: white;
          padding: 25px;
          border-radius: 10px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .status {
          color: green;
          font-weight: bold;
          margin: 10px 0;
        }

        button {
          background: #2563eb;
          color: white;
          border: none;
          padding: 10px 18px;
          border-radius: 6px;
          cursor: pointer;
        }
      </style>
    </head>

    <body>

      <h1>Orders</h1>

      <div class="orders">

        <div class="card">
          <h2>Order #1001</h2>

          <p class="status">Delivered</p>

          <p>Total: $248</p>

          <button>View Details</button>
        </div>

        <div class="card">
          <h2>Order #1002</h2>

          <p class="status">Processing</p>

          <p>Total: $99</p>

          <button>View Details</button>
        </div>

      </div>

    </body>
    </html>
  `);
});

app.listen(3000, () => {
  console.log("Order Service Running");
});