const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());

/* API */
app.get("/api/cart", (req, res) => {
  res.json([
    {
      id: 1,
      product: "Wireless Headphones",
      quantity: 1,
      price: 99
    },
    {
      id: 2,
      product: "Smart Watch",
      quantity: 2,
      price: 149
    }
  ]);
});

/* UI */
app.get("/cart", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Cart</title>

      <style>
        body {
          font-family: Arial;
          background: #f3f4f6;
          padding: 40px;
        }

        h1 {
          text-align: center;
          margin-bottom: 30px;
        }

        table {
          width: 100%;
          background: white;
          border-collapse: collapse;
          border-radius: 10px;
          overflow: hidden;
        }

        th, td {
          padding: 16px;
          border-bottom: 1px solid #ddd;
          text-align: center;
        }

        th {
          background: #111827;
          color: white;
        }

        .summary {
          margin-top: 30px;
          text-align: right;
        }

        button {
          background: #2563eb;
          color: white;
          border: none;
          padding: 12px 18px;
          border-radius: 6px;
          cursor: pointer;
        }
      </style>
    </head>

    <body>

      <h1>Shopping Cart</h1>

      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>Wireless Headphones</td>
            <td>$99</td>
            <td>1</td>
            <td>$99</td>
          </tr>

          <tr>
            <td>Smart Watch</td>
            <td>$149</td>
            <td>2</td>
            <td>$298</td>
          </tr>
        </tbody>
      </table>

      <div class="summary">
        <h2>Total: $397</h2>

        <button>Checkout</button>
      </div>

    </body>
    </html>
  `);
});

app.listen(3000, () => {
  console.log("Cart Service Running");
});