CREATE DATABASE IF NOT EXISTS ecommerce;

USE ecommerce;

CREATE TABLE products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255),
  price INT
);

INSERT INTO products(name, price)
VALUES
('Wireless Headphones', 99),
('Smart Watch', 149);