import "./styles.css";

const app = document.createElement("div");

app.innerHTML = `
  <header class="header">
    <h1>Mini E-Commerce Platform</h1>

    <nav>
      <a href="#">Home</a>
      <a href="#">Products</a>
      <a href="#">Cart</a>
      <a href="#">Orders</a>
    </nav>
  </header>

  <section class="hero">
    <h2>Shop Smart</h2>

    <p>
      Modern Microservices Based E-Commerce Platform
      using Docker, Kubernetes, Jenkins & AWS
    </p>

    <button class="btn">Explore Products</button>
  </section>

  <section class="products">

    <div class="card">
      <img src="https://picsum.photos/300/200?1" alt="product" />

      <h3>Wireless Headphones</h3>

      <p>$99</p>

      <button class="btn">Add To Cart</button>
    </div>

    <div class="card">
      <img src="https://picsum.photos/300/200?2" alt="product" />

      <h3>Smart Watch</h3>

      <p>$149</p>

      <button class="btn">Add To Cart</button>
    </div>

    <div class="card">
      <img src="https://picsum.photos/300/200?3" alt="product" />

      <h3>Gaming Keyboard</h3>

      <p>$79</p>

      <button class="btn">Add To Cart</button>
    </div>

    <div class="card">
      <img src="https://picsum.photos/300/200?4" alt="product" />

      <h3>Bluetooth Speaker</h3>

      <p>$59</p>

      <button class="btn">Add To Cart</button>
    </div>

  </section>

  <footer class="footer">
    <p>
      © 2026 Mini E-Commerce Platform
    </p>
  </footer>
`;

document.body.appendChild(app);