CREATE DATABASE ecommerce;

USE ecommerce;

CREATE TABLE products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  price INT
);

INSERT INTO products(name, price)
VALUES
('Laptop', 50000),
('Phone', 20000),
('Watch', 5000);