resource "aws_instance" "serv" {
  instance_type = var.type
  ami = var.ami
  tags = {
    name = "demoServer"
  }
  key_name = "EC2_key"
  vpc_security_group_ids = ["sg-0c799654f3f331e38"]
  root_block_device {
    volume_size = 10
    volume_type = "gp3"
  }
  count = 2
}