output "ip" {
  value = aws_instance.serv[*].public_ip
}