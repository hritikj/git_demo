variable "ami" {
  default = "ami-0236922087fa98b6e"
  type = string
}

variable "type" {
  default = "t3.micro"
  type = string
}