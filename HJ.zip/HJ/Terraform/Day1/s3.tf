resource "aws_s3_bucket" "mybuck"{
    region = var.region
    bucket = var.buck-name
    force_destroy = true
}

variable "buck-name" {
  default = "my-var-s3-buck-terraform"
  type = string
}

variable "region" {
  default = "ap-south-1"
  type = string
}

output "arn" {
  value = aws_s3_bucket.mybuck.arn
}