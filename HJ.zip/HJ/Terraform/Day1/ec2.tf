resource "aws_instance" "my_serv" {
 instance_type = var.type
 ami = var.ami
 tags = {
    name = "demo server"
 }
 

}

variable "ami" {
  default = "ami-0236922087fa98b6e"
  type = string
}

variable "type" {
  default = "t3.micro"
  type = string
}

output "ip" {
  value = aws_instance.my_serv.public_ip
  
}

