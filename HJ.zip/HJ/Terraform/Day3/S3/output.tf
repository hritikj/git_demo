output "buckarn" {
  value = aws_s3_bucket.mybuck.arn
}

output "buckregion" {
  value = aws_s3_bucket.mybuck.region
}