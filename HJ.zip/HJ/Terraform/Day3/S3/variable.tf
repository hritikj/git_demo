variable "buck" {
  default = "my-sr-34256-bucket"
  type = string
}

variable "region" {
  default = "ap-south-1"
  type = string
}