resource "aws_s3_bucket" "mybuck" {
  bucket = var.buck
  region = var.region
  force_destroy = true
}