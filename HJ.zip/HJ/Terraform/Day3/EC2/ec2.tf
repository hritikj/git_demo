resource "aws_instance" "serv" {
  instance_type = var.type
  ami = var.ami
  tags = {
    Name = "demoServer"
  }
  key_name = "EC2_key"
  vpc_security_group_ids = ["sg-0c799654f3f331e38"]
  root_block_device {
    volume_size = 10
    volume_type = "gp3"
  }
  user_data = file("C:\\Users\\AjeetkumarVerma\\Downloads\\HJ\\Terraform\\Day3\\EC2\\user-data.txt")
  count = 1
}