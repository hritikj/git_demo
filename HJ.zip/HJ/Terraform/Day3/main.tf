module "s3" {
  source = "./S3"
}

module "ec2" {
  source = "./EC2"
}