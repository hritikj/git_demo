output "arn" {
  value = module.s3.buckarn
}

output "region" {
  value = module.s3.buckregion
}

output "ip" {
  value = module.ec2.ip
}