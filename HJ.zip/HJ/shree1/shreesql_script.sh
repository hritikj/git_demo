#!/bin/bash
DB_NAME="shree"
DB_USER="myuser"
DB_PASS="mypassword"
#Create Database, user and provide all privileges
CREATE DATABASE shree;
CREATE USER 'myuser'@'localhost' IDENTIFIED BY 'mypassword';
GRANT ALL PRIVILEGES ON mydatabase.* TO 'myuser'@'localhost';
FLUSH PRIVILEGES;
EXIT;